def generate_entity(result):
#     print(result)
#     for res in result:
#         outputs = generate_entities(result[res]['content'])
#         generated_entity = outputs["generated_entity"]
#         result[res]['entity'] = generated_entity
#     print(result)

#     return result